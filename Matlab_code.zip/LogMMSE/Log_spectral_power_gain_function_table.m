function [Gain]=log_gain_functions_table()



priori_range=-40:1:50;  % range of a priori values
poster_range=-40:1:50;  % range of a posteriori values

priori=10.^(priori_range(:)'/10);%Rksi and Rgam are in dBs.
post=10.^(poster_range/10);
G=zeros(length(priori_range),length(poster_range));

for k =1:length(priori_range)
	SNR_priori = priori(k);
	eta = post/SNR_priori/(1+SNR_priori);
	Gain(k,:) = (1/(1+SNR_priori))^2 * exp(expint(eta));
end 
Gain = real(Gain);