function [logestimate]=noise_psdest(log_gain,noisy_dft_frame_p, I,noise_psd_old,xiest,a_post_snr)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%This m-file estimates the noise PSD and applies bias compensation
%%%%
%%%%Input parameters:   noisy_dft_frame:    noisy DFT frame
%%%%                    noise_psd_old:      estimated noise PSD of previous frame,
%%%%                    speech_psd:         estimated speech PS
%%%%                    I:                  frame number
%%%%
%%%%Output parameters:  noise_psd:          estimated noise PSD
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%  Author: Qiquan Zhang, 17/10/2017
%%%%%%%%%%%%%%%%%%%%%%% copyright: Harbin Institute of Technology
%%%%%%%%%%%%%%%%%%%%%

% init_per=5; % initial number of frames of noisy wave-file that are assumed to be noise only


% a_post_snr=(noisy_dft_frame_p)./noise_psd_old;
% --------------------------------- original priori SNR estimation ----------------------------
% xiest = speech_psd./noise_psd_old;
prioridb = round(10*log10(xiest));
postdb = round(10*log10(a_post_snr));
% Index_post = min(max(min(-40:1:50),postdb), max(-40:1:50));
% Index_post = Index_post-min(-40:1:50)+1;
Index_post = min(max(-40,postdb), 50);
Index_post = Index_post+40+1;

% Index_pri = min(max(min(-40:1:50),prioridb), max(-40:1:50));
% Index_pri = Index_pri-min(-40:1:50)+1;
Index_pri = min(max(-40,prioridb), 50);
Index_pri = Index_pri+40+1;
gain_function = log_gain(Index_pri+(Index_post-1)*length(log_gain(:,1)));
% --------------------------------------------------------------------------------------------%
% xiest = max(a_post_snr-1,eps);
v = a_post_snr./xiest./(1 + xiest);
exp_int = expint(v);

gain_function = exp(exp_int)./((1 + xiest).^2);
gain_function = min(gain_function,0.99);
% PH1 = 1./(1+exp(-0.97*(a_post_snr - 3.6)));

% ------------------------------------------------------------ %
% gain_function = (1./(1+xiest)).^(2); 
% ------------------------------------------------------------ %
% logestimate = (gain_function.*(noisy_dft_frame_p)).^(PH1).*(noisy_dft_frame_p).^(1-PH1);
logestimate = gain_function.*noisy_dft_frame_p;
% noise_psd = 0.8 *noise_psd_old+(1-0.8)*estimate; 





function mx=freqsmooth(x,w)
% Smoothing over 2*w+1 neighboring frequency bins
L=length(x);mx=zeros(size(x));
for k=1:L
    i1=max(k-w,1);i2=min(k+w,L);
    mx(k)=sum(x(i1:i2))/(i2-i1+1);
end



function y=ei(x)
% ei - is an exponential integral
% ================================
% Usage:
%       y=ei(x)
% 
% Defined by :
%                inf
%  E1(x)=-Ei(-x)= S exp(-t)/t dt
%                 x
if min(x)>0,
      x=(x<20).*x+(x>=20).*20;
      az=1;
      s=0;
      for i=1:100,
          az=az*i;
          s=s+((-x).^i)/(i*az);
      end;
      s=-(0.577215+log(x)+s);
      y=sign(20-x).*(sign(20-x)+1).*s/2;
   else 
   the_value_cannot_be_zero_or_negative
end