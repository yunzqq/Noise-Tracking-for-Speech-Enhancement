function [shat_logmmse_spp,noisePsdMat_spp,T_Logspp] = noisePsdestiamtion(noisy,fs)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% propose logMMSE algorithm to estimate the spectral noise power
%%%% Input :        noisy:  noisy signal
%%%%                   fs:  sampling frequency
%%%%                   
%%%% Output:  noisePsdMat:  matrix with estimated noise power for each frame
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%% Copyright (c) 2017, Qiquan Zhang
%%%%%%%%%%%%%%%%%%%%%% Author: Qiquan Zhang
%%%%%%%%%%%%%%%%%%%%%% Harbin Institute of Technology
%%%%%%%%%%%%%%%%%%%%%% KTH Royal Institute of Technology
%%%%%%%%%%%%%%%%%%%%%% Delft university of Technology
%%%%%%%%%%%%%%%%%%%%%% Contact: zhangqiquan_hit@163.com
% All rights reserved.
%
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are
% met:
%
%     * Redistributions of source code must retain the above copyright
%       notice, this list of conditions and the following disclaimer.
%     * Redistributions in binary form must reproduce the above copyright
%       notice, this list of conditions and the following disclaimer in
%       the documentation and/or other materials provided with the distribution
%     * Neither the name of the Universitaet Oldenburg, Delft university, KTH 
%	Royal Institute of Technology nor the names of its contributors may be 
% 	used to endorse or promote products derived from this software without 
% 	specific prior written permission.
%
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
% AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
% IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
% ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
% LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
% CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
% SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
% INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
% CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
% ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
% POSSIBILITY OF SUCH DAMAGE.
%
% Version v1.0 (October 2017)
% --------------------------------------------------------------------------------------%
log_gain = Log_spectral_power_gain_function_table();
% ---------------------------------- some constants -------------------------------------
% ------------------------- parameters setting of speech estimators --------------------- 
MIN_GAIN =eps;
gamma=1;
nu=0.6;
[g_dft,g_mag,g_mag2]=Tabulate_gain_functions(gamma,nu);
% ---------------------------------------------------------------------------------------

frLen   = 32e-3*fs;  % frame size
fShift  = frLen/2;   % fShift size
nFrames = floor(length(noisy)/fShift)-1; % number of frames
fft_size = frLen;    % FFT length


% ------------------------------- window function ----------------------------
anWin  = sqrt(hanning(frLen)); %analysis window
synWin = sqrt(hanning(frLen)); % synthesis window
% anWin  = hanning(frLen,'periodic'); %analysis window
% anWin  = hanning(frLen,'periodic'); %synthesis window
% -------------------------- allocate some memory --------------------------
noisePsdMat_spp = zeros(frLen/2+1,nFrames);


% ------------------------------ initialize ----------------------------
noisePow = init_noise_tracker_ideal_vad(noisy,frLen,frLen,fShift, anWin); 
% This function computes the initial noise PSD estimate. It is assumed that the first 5 time-frames are noise-only.
noisePsdMat_spp(:,1) = noisePow;
% --------------------------------------------------------------------- %
% --------------------------------------------------------------------- %
gain = ones(frLen/2+1,1);


clean_est_dft_frame = [];
clean_est_dft_frame_p = [];
shat_logmmse_spp=zeros(size(noisy));


% ----------------- safety net parameters setting ---------------------%
eta = 0.1;
B = 1.5;
min_mat = zeros(frLen/2+1,floor(0.8*fs/fShift));
% ----------------------- noise update setting ------------------------%
alphap = 0.2;
alphad = 0.8;
T1 = 5 * ones(frLen/8+1,1);
T2 = 6.5 * ones(frLen/4,1);
T3 = 8 * ones(frLen/8,1);
T = [T1;T2;T3];
Psp = zeros(frLen/2+1,1);
Isp = zeros(frLen/2+1,1);
% ---------------------------------------------------------------------%
SNR_LOW_LIM = 0.0316;
MIN_GAIN = eps;
% -------------------------------------------------------------------- %
alpha =  0.98;
% --------------------------- processing ----------------------------- %
a_post_snr_bias_matrix = zeros(frLen/2+1,3);
% ------------------------ posteriori SNR estimation ----------------- %
tic
for indFr = 1:nFrames
    indices       = (indFr-1)*fShift+1:(indFr-1)*fShift+frLen;
    noisy_frame   = anWin.*noisy(indices);
    noisyDftFrame = fft(noisy_frame,frLen);
    noisyDftFrame = noisyDftFrame(1:frLen/2+1);
    % noisyPer = noisyDftFrame.*conj(noisyDftFrame);
    noisyPer = abs(noisyDftFrame).^2;


	[a_post_snr_bias,a_priori_snr_bias]=estimate_snrs_bias(noisyPer,fft_size,noisePow,SNR_LOW_LIM,alpha,indFr,clean_est_dft_frame_p);
    % speech_psd = a_priori_snr_bias.*noisePow;

    % [logestimate]=noise_psdest_tab_spp(log_gain, noisyPer,indFr,speech_psd,noisePow,a_priori_snr_bias,a_post_snr_bias);
    [logestimate]=noise_psdest_tab_spp(log_gain, noisyPer,indFr,noisePow,a_priori_snr_bias,a_post_snr_bias);
    % a_post_snr_bias_matrix(:,1:2) = a_post_snr_bias_matrix(:,2:3);
    % a_post_snr_bias_matrix(:,3) = a_post_snr_bias;
    % --------------------------------------------------------------------------------------
    Mpost = freqsmooth(a_post_snr_bias,1);
    % Mpost = freqsmooth(a_post_snr_bias_matrix,1, indFr);  
    Isp = (Mpost>T);
    Psp = alphap.*Psp + (1-alphap).*Isp;
    alphas = alphad + (1-alphad).*Psp;
    noisePow = alphas.*noisePow + (1-alphas).*logestimate;
    % --------------------------------------- safety net -----------------------------------
    % min_mat = [min_mat(:,end-floor(0.8*fs/fShift)+2:end),noisyPer(1:fft_size/2+1)];
    min_mat=UpdatePsm(min_mat,abs(noisyDftFrame),eta);
    % % % --------------------------------------------------------------------------------------
    Pmin = min(min_mat,[],2);
    I=find(Pmin./noisePow>1/B);
    if ~isempty(I)
        Psp(I)=0;
        noisePow(I)=B*Pmin(I);
        logestimate(I)=max(noisePow(I),logestimate(I));
        alphas(I)=0;
        noisePow(I)=alphas(I).*noisePow(I)+(1-alphas(I)).*logestimate(I);
    end
    % noisePow = max(noisePow,min(min_mat,[],2));
    % --------------------------------------------------------------------------------------

    % --------------------------------------------------------------------------------------
    [a_post_snr,a_priori_snr] = estimate_snrs(noisyPer,fft_size,noisePow,SNR_LOW_LIM,alpha,indFr,clean_est_dft_frame_p)   ;
    % --------------------------------------------------------------------------------------
    % --------------------------------------------------------------------------------------
    [gain]= lookup_gain_in_table(g_mag,a_post_snr,a_priori_snr,-40:1:50,-40:1:50,1);
    gain = max(gain,MIN_GAIN);
    % --------------------------------------------------------------------------------------

    % --------------------------------------------------------------------------------------
    % --------------------------------------------------------------------------------------
   
    clean_est_dft_frame = gain.*(noisyDftFrame);
    clean_est_dft_frame_p = abs(clean_est_dft_frame).^2;
    noisePsdMat_spp(:,indFr) = noisePow;
    shat_logmmse_spp(indices)=shat_logmmse_spp(indices) + synWin.*real(ifft( [clean_est_dft_frame;flipud(conj(clean_est_dft_frame(2:end-1)))]));
end
T_Logspp = toc;
% return





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function   noise_psd_init =init_noise_tracker_ideal_vad(noisy,fr_size,fft_size,hop,sq_hann_window)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%This m-file computes an initial noise PSD estimate by means of a
%%%%Bartlett estimate.
%%%%Input parameters:   noisy:          noisy signal
%%%%                    fr_size:        frame size
%%%%                    fft_size:       fft size
%%%%                    hop:            hop size of frame
%%%%                    sq_hann_window: analysis window
%%%%Output parameters:  noise_psd_init: initial noise PSD estimate
%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%Author: Richard C. Hendriks, 15/4/2010
%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%
 
for I=1:5
    noisy_frame=sq_hann_window.*noisy((I-1)*hop+1:(I-1)*hop+fr_size);
    noisy_dft_frame_matrix(:,I)=fft(noisy_frame,fft_size);
end
noise_psd_init=mean(abs(noisy_dft_frame_matrix(1:fr_size/2+1,1:end)).^2,2);%%%compute the initialisation of the noise tracking algorithms.
return



function mx=freqsmooth(x,w)
% Smoothing over 2*w+1 neighboring frequency bins
L=length(x);
mx=zeros(size(x));
% mx(1) = x(1);
% mx(end) = x(end);
for k=1:L
    i1=max(k-w,1);
    i2=min(k+w,L);
    % mx(k)=x(i1:i2)'*[0.25 0.5 0.25]';
    mx(k)=sum(x(i1:i2))/(i2-i1+1);
end

% function mx=freqsmooth(x,w,FrameIndex)
% % Smoothing over 2*w+1 neighboring frequency bins
% L=length(x(:,1));
% mx=zeros(size(x(:,1)));
% matrix1 = [0 0.1 0.25;
%           0 0.25 0.4];
% matrix = [0 0.1 0.2;
%           0 0.2 0.2
%           0 0.1 0.2];
% % mx(1) = x(1);
% % mx(end) = x(end);
% if FrameIndex == 1
%     for k=1:L
%         i1=max(k-w,1);
%         i2=min(k+w,L);
%         % mx(k)=x(i1:i2)'*[0.25 0.5 0.25]';
%         mx(k)=sum(x(i1:i2,3))/(i2-i1+1);
%     end
% elseif FrameIndex == 2
%     for k=1:L
%         i1=max(k-w,1);
%         i2=min(k+w,L);
%         % mx(k)=x(i1:i2)'*[0.25 0.5 0.25]';
%         mx(k)=sum(sum(x(i1:i2,2:3)))/((i2-i1+1)*3);
%     end
% else
%     mx(1)=sum(sum(matrix1.*x(1:2,1:3)));
%     % /((i2-i1+1)*3);
%     mx(L)=sum(sum(matrix1.*x(L-1:L,1:3)));
%     % /((i2-i1+1)*3);
%     for k=2:L-1
%         i1=max(k-w,1);
%         i2=min(k+w,L);
%         % mx(k)=x(i1:i2)'*[0.25 0.5 0.25]';
%         mx(k)=sum(sum(matrix.*x(i1:i2,1:3)));
%         % /((i2-i1+1)*3);
%     end
% end






function min_mat=UpdatePsm(min_mat,R,eta)
% Update the window of smoothed noisy spectral values
% Shift it
min_mat(:,1:end-1) = min_mat(:,2:end);
min_mat(:,end) = eta*min_mat(:,end-1) + (1-eta)*R.^2;
% Psm(1:end-1,:)=Psm(2:end,:);
% % Update last one
% Psm(end,:)=eta*Psm(end-1,:)+(1-eta)*R.^2;